package com.example.mhaod.myapplication;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity  {
    //the command for diverse operation
    private byte[] bytedown = "ONB".getBytes();
    private byte[] byteleft = "ONC".getBytes();
    private byte[] byteright = "OND".getBytes();
    private byte[] byteup = "ONA".getBytes();
    private byte[] bytestop = "ONF".getBytes();

    private int ENABLE_BLUETOOTH=2;
    private BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    BluetoothDevice bluetoothDevice;
    BluetoothSocket bluetoothSocket = null;
    OutputStream outputStream = null;
    private static final UUID MY_UUID_SECURE=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private String blueAddress="00:14:03:06:8B:CE";//MAC address of the Bluetooth

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(bluetoothAdapter==null){
            Toast.makeText(this,"Do not support the Bluetooth",Toast.LENGTH_LONG).show();
            finish();
        }else if(!bluetoothAdapter.isEnabled()){
            Log.d("true","Starting Connecting");
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent,ENABLE_BLUETOOTH);
        }
        //add listener
        ButtonListener bt = new ButtonListener();
        ImageButton forward = (ImageButton)findViewById(R.id.imagebutton1);
        ImageButton left = (ImageButton)findViewById(R.id.imagebutton2);
        ImageButton right = (ImageButton)findViewById(R.id.imagebutton3);
        ImageButton backward = (ImageButton)findViewById(R.id.imagebutton4);

        forward.setOnTouchListener(bt);
        left.setOnTouchListener(bt);
        right.setOnTouchListener(bt);
        backward.setOnTouchListener(bt);
    }

    class ButtonListener implements View.OnTouchListener {

        public boolean onTouch(View v, MotionEvent event) {
            switch (v.getId()){
                case R.id.imagebutton1:
                    if(event.getAction() == MotionEvent.ACTION_UP){//release event
                        bluesend(bytestop);//send message
                    }
                    if(event.getAction() == MotionEvent.ACTION_DOWN){//push event
                        bluesend(byteup);//send message
                    }
                    break;
                case R.id.imagebutton2:
                    if(event.getAction() == MotionEvent.ACTION_UP){//release event
                        bluesend(bytestop);//send message
                    }
                    if(event.getAction() == MotionEvent.ACTION_DOWN){//push event
                        bluesend(byteleft);//send message
                    }
                    break;
                case R.id.imagebutton3:
                    if(event.getAction() == MotionEvent.ACTION_UP){//release event
                        bluesend(bytestop);//send message
                    }
                    if(event.getAction() == MotionEvent.ACTION_DOWN){//push event
                        bluesend(byteright);//send message
                    }
                    break;
                case R.id.imagebutton4:
                    if(event.getAction() == MotionEvent.ACTION_UP){//release event
                        bluesend(bytestop);//send message
                    }
                    if(event.getAction() == MotionEvent.ACTION_DOWN){//push event
                        bluesend(bytedown);//send message
                    }
                    break;
                default:
                    break;
            }
            return false;
        }

    }

    //Bluetooth sends message
    public void bluesend(byte[] message){
        try{
            outputStream = bluetoothSocket.getOutputStream();
            Log.d("send", Arrays.toString(message));
            outputStream.write(message);
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        try{
            bluetoothSocket.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume(){
        super.onResume();
        Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();
        bluetoothDevice = bluetoothAdapter.getRemoteDevice(blueAddress);
        try{
            bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(MY_UUID_SECURE);
            Log.d("true","Start Connecting");
            bluetoothSocket.connect();
            Log.d("true","Connect Finished");
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

